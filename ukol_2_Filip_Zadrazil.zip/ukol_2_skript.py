import json, pyproj, math, statistics
from pyproj import Transformer
from math import hypot 

def containers_file(container_file):
    with open(container_file, encoding = 'utf-8') as f:
        containers_input = json.load(f)
        features = containers_input['features']
    return features

def osetreni_pristupu(features):
    containers_coord_wgs = []
    for feature in features:
        if feature['properties']['PRISTUP'] == 'volně':
            souradnice = feature['geometry']['coordinates']
            containers_coord_wgs.append(souradnice)
    return containers_coord_wgs

def address_file_open(address_file):
    with open(address_file, encoding = 'utf-8') as f:
        address_input = json.load(f)
        addresses = address_input['features']
    return addresses

def address_points(addresses):
    position = []
    transformer = Transformer.from_crs(4326, 5514, always_xy=True)
    for adresa in addresses:
        zaznam = {}
        zaznam['adresa'] = adresa['properties']['addr:street'] + ' ' + adresa['properties']['addr:housenumber']
        zaznam['souradnice'] = transformer.transform(adresa['geometry']['coordinates'][0], adresa['geometry']['coordinates'][1])
        position.append(zaznam)
    return position

def containers_to_sjtsk(containers_coord_wgs):
    containers_coord_sjtsk = []
    transformer = Transformer.from_crs(4326, 5514, always_xy=True)
    for pt in transformer.itransform(containers_coord_wgs):
        containers_coord_sjtsk.append(pt)
    return containers_coord_sjtsk

def address_point_container_distance(position, containers_coord_sjtsk):
    biggest_distance_address = 'David'
    distances = []
    highest_value = 0
    for adresa in position:
        shortest_distance = 10000
        for kontejner in containers_coord_sjtsk:
            diff_lon = adresa['souradnice'][0] - kontejner[0]
            diff_lat = adresa['souradnice'][1] - kontejner[1]
            distance = math.hypot(diff_lon, diff_lat)
            if distance <= shortest_distance:
                shortest_distance = distance
        distances.append(shortest_distance)
        if shortest_distance > highest_value:
            highest_value = shortest_distance
            biggest_distance_address = adresa['adresa']
    return highest_value, biggest_distance_address, distances

features = containers_file("kontejnery.geojson")
addresses = address_file_open("adresy.geojson")  
containers_coord_wgs = osetreni_pristupu(features) 
position = address_points(addresses) 
containers_coord_sjtsk = containers_to_sjtsk(containers_coord_wgs)
highest_value, biggest_distance_address, distances = address_point_container_distance(position, containers_coord_sjtsk)
  
mean = statistics.mean(distances)
median = statistics.median(distances)

print("Celkem načteno", len(position), "adresních bodů")
print("Celkem načteno", len(containers_coord_wgs), "kontejnerů na tříděný odpad")
print("Průměrná vzdálenost z adresního bodu ke kontejneru je:", round(mean), "m")
print("Medián vzdáleností z adresního bodu ke kontejneru je:", round(median), "m")
print("Největší vzdálenost ke kontejneru je", round(highest_value), "m a to z adresy", biggest_distance_address)
